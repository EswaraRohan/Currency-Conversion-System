#!/bin/sh
gcc priorityqueue.c graph.c UserInterface.c mainfinal.c -o MainWithUI
./MainWithUI